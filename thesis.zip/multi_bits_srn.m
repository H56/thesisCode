clear; close all; clc;

files_root_path = 'music_pieces/';
all_files = dir(fullfile(files_root_path, '*.wav'));
count = length(all_files);

times = 100;
n = [20 40 60 80 100 120 140 160 180 200 220 240 260 280 300 320
    340 360 380 400 420 440 460 480 500 520 540 560 580 600 620 640];
num_watermark = 32;
Lpn = 1023;
a_set = [0.001 0.002 0.004 0.006];

result = zeros(length(a_set), 5);
% count_water = 0;
for t = 1 : times
    for i = 1 : count
        [x, fs] = wavread(strcat(files_root_path, all_files(i).name));
        k = PNSequence(Lpn);
        j = 1;
        for a = a_set
			w = randi(2, 1, 8) - 1;
            y1 = echo_encode(x, w, k, a, n(1 : 2));
            
			w = [w randi(2, 1, length(w)) - 1];
            y2 = multi_bits_encode(x, w, k, a, n(1 : 4));
			
			w = [w randi(2, 1, length(w)) - 1];
            y3 = multi_bits_encode(x, w, k, a, n(1 : 8));
			
			w = [w randi(2, 1, length(w)) - 1];
            y4 = multi_bits_encode(x, w, k, a, n(1 : 16));
			
			w = [w randi(2, 1, length(w)) - 1];
            y5 = multi_bits_encode(x, w, k, a, n(1 : 32));
        
            result(j, 1) = result(j, 1) + SNR(x, y1);
            result(j, 2) = result(j, 2) + SNR(x, y2);
            result(j, 3) = result(j, 3) + SNR(x, y3);
            result(j, 4) = result(j, 4) + SNR(x, y4);
            result(j, 5) = result(j, 5) + SNR(x, y5);
            j = j + 1;
        end
    end
	disp(t);
end
result = result / (count * times)