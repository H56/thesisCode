clear; close all; clc;

files_root_path = 'music_pieces/';
all_files = dir(fullfile(files_root_path, '*.wav'));
count = length(all_files);

times = 100;
n = [20 40 60 80 100 120 140 160 180 200 220 240 260 280 300 320
    340 360 380 400 420 440 460 480 500 520 540 560 580 600 620 640];
num_watermark = 32;
Lpn = 1023;
a = 0.002;
snr = 0;

result = zeros(3, 5);
% count_water = 0;
for t = 1 : times   
    for i = 1 : count
		[x, fs] = wavread(strcat(files_root_path, all_files(i).name));
        k = PNSequence(Lpn);
        w = randi(2, 1, num_watermark) - 1;
        y1 = echo_encode(x, w, k, a, n(1 : 2));
% 		y1_a = wav_quantize(y1, 8);
% 		y1_aw = awgn(y1, 30, 'measured');
        mp3write(y1, fs, 'tmp.mp3',  '--quiet -h -b 128'); y1_a = mp3read('tmp.mp3');
        m4awrite(y1, fs, 'tmp.m4a',  '-b 128'); [y1_aw fs] = m4aread('tmp.m4a'); y1_aw = y1_aw(1 : 441000, 1);
        y1 = 1.8 * y1;
        w1 = echo_decode(y1, num_watermark, k, n(1 : 2));
		result(1, 1) = result(1, 1) + sum(w == w1);
		w1 = echo_decode(y1_a, num_watermark, k, n(1 : 2));
		result(2, 1) = result(2, 1) + sum(w == w1);
		w1 = echo_decode(y1_aw, num_watermark, k, n(1 : 2));
		result(3, 1) = result(3, 1) + sum(w == w1);
        
        y2 = multi_bits_encode(x, w, k, a, n(1 : 4));
		mp3write(y2, fs, 'tmp.mp3',  '--quiet -h -b 128'); y2_a = mp3read('tmp.mp3');
        m4awrite(y2, fs, 'tmp.m4a',  '-b 128'); [y2_aw fs] = m4aread('tmp.m4a'); y2_aw = y2_aw(1 : 441000, 1);
        y2 = 1.8 * y2;
        w2 = multi_bits_decode(y2, num_watermark, k, n(1 : 4));
		result(1, 2) = result(1, 2) + sum(w == w2);
		w2 = multi_bits_decode(y2_a, num_watermark, k, n(1 : 4));
		result(2, 2) = result(2, 2) + sum(w == w2);
		w2 = multi_bits_decode(y2_aw, num_watermark, k, n(1 : 4));
		result(3, 2) = result(3, 2) + sum(w == w2);
        
        y3 = multi_bits_encode(x, w, k, a, n(1 : 8));
		mp3write(y3, fs, 'tmp.mp3',  '--quiet -h -b 128'); y3_a = mp3read('tmp.mp3');
        m4awrite(y3, fs, 'tmp.m4a',  '-b 128'); [y3_aw fs] = m4aread('tmp.m4a'); y3_aw = y3_aw(1 : 441000, 1);
        y3 = 1.8 * y3;
        w3 = multi_bits_decode(y3, num_watermark, k, n(1 : 8));
		result(1, 3) = result(1, 3) + sum(w == w3);
		w3 = multi_bits_decode(y3_a, num_watermark, k, n(1 : 8));
		result(2, 3) = result(2, 3) + sum(w == w3);
		w3 = multi_bits_decode(y3_aw, num_watermark, k, n(1 : 8));
		result(3, 3) = result(3, 3) + sum(w == w3);
        
        y4 = multi_bits_encode(x, w, k, a, n(1 : 16));
		mp3write(y4, fs, 'tmp.mp3',  '--quiet -h -b 128'); y4_a = mp3read('tmp.mp3');
        m4awrite(y4, fs, 'tmp.m4a',  '-b 128'); [y4_aw fs] = m4aread('tmp.m4a'); y4_aw = y4_aw(1 : 441000, 1);
        y4 = 1.8 * y4;
        w4 = multi_bits_decode(y4, num_watermark, k, n(1 : 16));
        result(1, 4) = result(1, 4) + sum(w == w4); 
		w4 = multi_bits_decode(y4_a, num_watermark, k, n(1 : 16));
        result(2, 4) = result(2, 4) + sum(w == w4); 
		w4 = multi_bits_decode(y4_aw, num_watermark, k, n(1 : 16));
        result(3, 4) = result(3, 4) + sum(w == w4); 
		
		y5 = multi_bits_encode(x, w, k, a, n(1 : 32));
		mp3write(y5, fs, 'tmp.mp3',  '--quiet -h -b 128'); y5_a = mp3read('tmp.mp3');
        m4awrite(y5, fs, 'tmp.m4a',  '-b 128'); [y5_aw fs] = m4aread('tmp.m4a'); y5_aw = y5_aw(1 : 441000, 1);
        y5 = 1.8 * y5;
        w5 = multi_bits_decode(y5, num_watermark, k, n(1 : 32));
        result(1, 5) = result(1, 5) + sum(w == w5); 
		w5 = multi_bits_decode(y5_a, num_watermark, k, n(1 : 32));
        result(2, 5) = result(2, 5) + sum(w == w5); 
		w5 = multi_bits_decode(y5_aw, num_watermark, k, n(1 : 32));
        result(3, 5) = result(3, 5) + sum(w == w5); 
    end
	disp([t, result / (count * t) * 100]);
end
result = result / (count * times * num_watermark) * 100;