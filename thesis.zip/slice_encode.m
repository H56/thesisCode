function y = slice_encode(x, w, k, a, n, ns)
w = w + 1;
Lseg = floor(length(x) / length(w));
Lslice = floor(Lseg / ns);
y = [];
for i = 1 : length(w)
    xseg = x((i - 1) * Lseg + 1 : i * Lseg);
    kernel = echo_kernel(k, a, n(w(i)));
    for j = 1 : ns
        xslice = xseg((j - 1) * Lslice + 1 : j * Lslice);
        yslice = conv(xslice, kernel');
        yslice = yslice(1 : Lslice);
        y = [y; yslice];
    end        
end
y = [y; x(length(y) + 1 : end)];